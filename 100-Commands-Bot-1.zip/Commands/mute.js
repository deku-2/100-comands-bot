const Discord = require('discord.js')
const colors = require('../colors.json')
const client = require('../index.js')
const db = require('quick.db')
const ms = require('ms')

module.exports = {
    name: '',
    description: '',
    usage: '',
    category: '',
    guildOnly: true,
    async execute(message, args){
        
    }
}